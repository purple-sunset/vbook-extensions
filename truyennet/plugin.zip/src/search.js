load('config.js');
function execute(key, page) {
    if (!page) page = '0';

    return null;
}
