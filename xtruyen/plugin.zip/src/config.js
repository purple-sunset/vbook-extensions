const BASE_URL = 'https://xtruyen.vn';
